from django.apps import AppConfig


class ResidentialConfig(AppConfig):
    name = 'residential'
