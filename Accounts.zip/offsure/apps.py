from django.apps import AppConfig


class OffsureConfig(AppConfig):
    name = 'offsure'
