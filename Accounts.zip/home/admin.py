from django.contrib import admin
from .models import HomeDashboardSlider
# Register your models here.

admin.site.register(HomeDashboardSlider)